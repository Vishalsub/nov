import rclpy
from rclpy.action import ActionClient
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from rclpy.node import Node

class FollowJointTrajectoryClient(Node):
    def __init__(self):
        super().__init__('follow_joint_trajectory_client')
        self._action_client = ActionClient(self, FollowJointTrajectory, '/joint_trajectory_position_controller/follow_joint_trajectory')

    def send_goal(self):
        # Wait for the action server to be ready
        self.get_logger().info('Waiting for action server...')
        if not self._action_client.wait_for_server(timeout_sec=10.0):
            self.get_logger().error('Action server not available')
            return
        
        # Create a goal message
        goal_msg = FollowJointTrajectory.Goal()

        # Set the joint names
        goal_msg.trajectory.joint_names = [
            'link_pair_1_joint', 'link_pair_2_joint', 'link_pair_3_joint', 
            'big_triangle_joint', 'big_triangle_middle_joint', 'big_triangle_mirror_joint'
        ]

        # Define the first trajectory point (0.9 radians)
        point1 = JointTrajectoryPoint()
        point1.positions = [0.9, 0.9, 0.9, -1.333, -1.333, 1.333]  # Set joint positions to 0.9 radians
        point1.time_from_start.sec = 5  # Time to reach the first target (5 seconds)

        # Define the second trajectory point (1.57 radians)
        point2 = JointTrajectoryPoint()
        point2.positions = [1.37, 1.37, 1.37, -1.333, -1.333, 1.333]  # Set joint positions to 1.57 radians
        point2.time_from_start.sec = 10  # Time to reach the second target (10 seconds from the start, i.e., 5 seconds after the first point)

        # Define the second trajectory point (1.57 radians)
        point3 = JointTrajectoryPoint()
        point3.positions = [1.47, 1.47, 1.47, -1.433, -1.433, 1.433]  # Set joint positions to 1.57 radians
        point3.time_from_start.sec = 15  # Time to reach the second target (10 seconds from the start, i.e., 5 seconds after the first point)

        point4 = JointTrajectoryPoint()
        point4.positions = [-1.37, -1.37, -1.37, 1.333, 1.333, -1.333]  # Set joint positions to 1.57 radians
        point4.time_from_start.sec = 20  # Time to reach the second target (10 seconds from the start, i.e., 5 seconds after the first point)

        point5 = JointTrajectoryPoint()
        point5.positions = [-0.9, -0.9, -0.9, 1.333, 1.333, -1.333]  # Set joint positions to 0.9 radians
        point5.time_from_start.sec = 25  # Time to reach the first target (5 seconds)

        point6 = JointTrajectoryPoint()
        point6.positions = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]  # Set joint positions to 0.9 radians
        point6.time_from_start.sec = 30  # Time to reach the first target (5 seconds)

        

        # Add the trajectory points to the trajectory
        goal_msg.trajectory.points = [point1, point2, point3, point4, point5, point6]

        # Send the goal to the action server
        self.get_logger().info('Sending goal...')
        self._send_goal_future = self._action_client.send_goal_async(goal_msg)
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        result = future.result()
        if result.accepted:
            self.get_logger().info('Goal accepted')
        else:
            self.get_logger().error('Goal rejected')

def main(args=None):
    rclpy.init(args=args)
    client = FollowJointTrajectoryClient()

    # Send the goal to the action server
    client.send_goal()

    # Spin the node to process callbacks
    rclpy.spin(client)

    # Shutdown ROS 2 when finished
    rclpy.shutdown()

if __name__ == '__main__':
    main()
