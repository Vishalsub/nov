import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
import math

class CubeDistanceCalculator(Node):
    def __init__(self):
        super().__init__('cube_distance_calculator')

        # Subscriber to the LaserScan data
        self.create_subscription(LaserScan, '/scan', self.laser_scan_callback, 10)

        # Set a threshold distance to decide if shape change is required
        self.distance_threshold = 1.0  # meters (this can be adjusted)

        # Define the angles that correspond to the left and right cubes
        # You can adjust the angle ranges based on your setup
        self.left_cube_angle_range = (-math.pi/4, 0)  # Left cubes between -45° and 0°
        self.right_cube_angle_range = (0, math.pi/4)  # Right cubes between 0° and 45°

    def laser_scan_callback(self, msg: LaserScan):
        ranges = msg.ranges
        angle_min = msg.angle_min
        angle_increment = msg.angle_increment

        # Initialize the variables to None at the start of the callback
        left_cube_distance = None
        right_cube_distance = None

        # Loop through the scan data and extract the distance at the desired angles
        for i, range_value in enumerate(ranges):
            angle = angle_min + i * angle_increment
            
            # Log the angle and range for debugging purposes
            self.get_logger().info(f"Angle: {angle} rad, Range: {range_value}")

            # Check if the current angle is in the left cube range
            if self.left_cube_angle_range[0] <= angle <= self.left_cube_angle_range[1]:
                if range_value < float('inf'):  # Ignore invalid range data
                    left_cube_distance = range_value

            # Check if the current angle is in the right cube range
            elif self.right_cube_angle_range[0] <= angle <= self.right_cube_angle_range[1]:
                if range_value < float('inf'):  # Ignore invalid range data
                    right_cube_distance = range_value

        # After processing all the ranges, check if both distances were found
        if left_cube_distance is not None and right_cube_distance is not None:
            distance = self.calculate_distance(left_cube_distance, right_cube_distance)
            self.get_logger().info(f"Distance between cubes: {distance} meters")
        else:
            self.get_logger().warn('Unable to detect both cubes')



    def calculate_distance(self, left_distance, right_distance):
        # Use simple geometry to calculate the distance between the cubes.
        # Since the robot is at the origin (0, 0) in the 2D plane:
        # The two cubes are located at (left_distance, angle_left) and (right_distance, angle_right)
        left_x = left_distance * math.cos(self.left_cube_angle_range[0])  # Convert polar to Cartesian coordinates
        left_y = left_distance * math.sin(self.left_cube_angle_range[0])
        
        right_x = right_distance * math.cos(self.right_cube_angle_range[0])
        right_y = right_distance * math.sin(self.right_cube_angle_range[0])

        # Calculate Euclidean distance between the two cubes
        return math.sqrt((right_x - left_x) ** 2 + (right_y - left_y) ** 2)

def main(args=None):
    rclpy.init(args=args)
    node = CubeDistanceCalculator()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()


# import rclpy
# from rclpy.action import ActionClient
# from control_msgs.action import FollowJointTrajectory
# from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
# from rclpy.node import Node

# class FollowJointTrajectoryClient(Node):
#     def __init__(self):
#         super().__init__('follow_joint_trajectory_client')
#         self._action_client = ActionClient(self, FollowJointTrajectory, '/joint_trajectory_position_controller/follow_joint_trajectory')

#     def send_goal(self):
#         # Wait for the action server to be ready
#         self.get_logger().info('Waiting for action server...')
#         if not self._action_client.wait_for_server(timeout_sec=10.0):
#             self.get_logger().error('Action server not available')
#             return
        
#         # Create a goal message
#         goal_msg = FollowJointTrajectory.Goal()

#         # Set the joint names
#         goal_msg.trajectory.joint_names = [
#             'link_pair_1_joint', 'link_pair_2_joint', 'link_pair_3_joint', 
#             'big_triangle_joint', 'big_triangle_middle_joint', 'big_triangle_mirrior_joint',
#             'link_1_joint', 'big_non-actuated_triangle_mirror_joint', 'link_2_joint', 'big_non-actuated_triangle_joint',
#             'link_3_joint', 'link_4_joint', 'small_triangle_joint', 'small_triangle_mirror_joint'

#         ]

#         # Define the first trajectory point 
#         point1 = JointTrajectoryPoint()
#         point1.positions = [0.9, 0.9, 0.9, 
#                             -1.333, -1.333, 1.333,
#                             1.333, 0.9, 1.333, -0.9,  
#                             1.333, 1.333, 0.9, 0.9 ]

#         point1.time_from_start.sec = 5  

#         point2 = JointTrajectoryPoint()
#         point2.positions = [1.37, 1.37, 1.37, 
#                             -1.393, -1.393, 1.393,
#                             1.393, 1.37, 1.393, -1.37,  
#                             1.393, 1.393, 1.37, 1.37 ]

#         point2.time_from_start.sec = 7  

#         point3 = JointTrajectoryPoint()
#         point3.positions = [1.52, 1.52, 1.52, 
#                             -1.52, -1.52, 1.52,
#                             1.52, 1.52, 1.52, -1.52,  
#                             1.52, 1.52, 1.52, 1.52 ]

#         point3.time_from_start.sec = 9 

#         point4 = JointTrajectoryPoint()
#         point4.positions = [0.0, 0.0, 0.0, 
#                             0.0, 0.0, 0.0,
#                             0.0, 0.0, 0.0, 0.0,  
#                             0.0, 0.0, 0.0, 0.0 ]

#         point4.time_from_start.sec = 12 




#         # Add the trajectory points to the trajectory
#         goal_msg.trajectory.points = [point1, point2, point3, point4]

#         # Send the goal to the action server
#         self.get_logger().info('Sending goal...')
#         self._send_goal_future = self._action_client.send_goal_async(goal_msg)
#         self._send_goal_future.add_done_callback(self.goal_response_callback)

#     def goal_response_callback(self, future):
#         result = future.result()
#         if result.accepted:
#             self.get_logger().info('Goal accepted')
#         else:
#             self.get_logger().error('Goal rejected')

# def main(args=None):
#     rclpy.init(args=args)
#     client = FollowJointTrajectoryClient()

#     # Send the goal to the action server
#     client.send_goal()

#     # Spin the node to process callbacks
#     rclpy.spin(client)

#     # Shutdown ROS 2 when finished
#     rclpy.shutdown()

# if __name__ == '__main__':
#     main()


import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from rclpy.action import ActionClient
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

class FollowJointTrajectoryClient(Node):
    def __init__(self):
        super().__init__('follow_joint_trajectory_client')
        
        # Action client to send joint trajectory
        self._action_client = ActionClient(self, FollowJointTrajectory, '/joint_trajectory_position_controller/follow_joint_trajectory')
        
        # Subscriber to laser scan topic
        self._laser_scan_subscriber = self.create_subscription(
            LaserScan,
            '/scan',  # This should be the topic name of your laser scan
            self.laser_scan_callback,
            10
        )
        
        self.laser_data = None  # To store laser scan data

    def laser_scan_callback(self, msg):
        # Process the incoming laser scan message
        self.laser_data = msg
        self.get_logger().info(f"Received LaserScan data with {len(msg.ranges)} ranges.")
        
        # Example: Check if the laser scan detects an obstacle within 1 meter
        if min(msg.ranges) < 1.0:  # Adjust the threshold as needed
            self.get_logger().warn("Obstacle detected! Aborting trajectory.")
            # Optionally, take action to avoid or stop movement
            self.abort_trajectory()
        else:
            self.get_logger().info("No obstacles detected. Sending trajectory goal.")
            # Proceed with sending the goal
            self.send_goal()

    def abort_trajectory(self):
        self.get_logger().info("Stopping robot movement.")
        # Logic to stop movement or adjust robot's action in response to the obstacle.
        # For instance, you could set a flag to stop the trajectory execution or send a "zero" trajectory.
    
    def send_goal(self):
        # Wait for the action server to be ready
        self.get_logger().info('Waiting for action server...')
        if not self._action_client.wait_for_server(timeout_sec=10.0):
            self.get_logger().error('Action server not available')
            return

        # Create a goal message for the trajectory
        goal_msg = FollowJointTrajectory.Goal()

        # Set the joint names
        goal_msg.trajectory.joint_names = [
            'link_pair_1_joint', 'link_pair_2_joint', 'link_pair_3_joint', 
            'big_triangle_joint', 'big_triangle_middle_joint', 'big_triangle_mirrior_joint',
            'link_1_joint', 'big_non-actuated_triangle_mirror_joint', 'link_2_joint', 
            'big_non-actuated_triangle_joint', 'link_3_joint', 'link_4_joint', 
            'small_triangle_joint', 'small_triangle_mirror_joint'
        ]

        # Define trajectory points based on laser scan data or preset values
        point1 = JointTrajectoryPoint()
        point1.positions = [0.9, 0.9, 0.9, 
                            -1.333, -1.333, 1.333,
                            1.333, 0.9, 1.333, -0.9,  
                            1.333, 1.333, 0.9, 0.9 ]
        point1.time_from_start.sec = 5  

        point2 = JointTrajectoryPoint()
        point2.positions = [1.37, 1.37, 1.37, 
                            -1.393, -1.393, 1.393,
                            1.393, 1.37, 1.393, -1.37,  
                            1.393, 1.393, 1.37, 1.37 ]
        point2.time_from_start.sec = 7  

        point3 = JointTrajectoryPoint()
        point3.positions = [1.52, 1.52, 1.52, 
                            -1.52, -1.52, 1.52,
                            1.52, 1.52, 1.52, -1.52,  
                            1.52, 1.52, 1.52, 1.52 ]
        point3.time_from_start.sec = 9 

        point4 = JointTrajectoryPoint()
        point4.positions = [0.0, 0.0, 0.0, 
                            0.0, 0.0, 0.0,
                            0.0, 0.0, 0.0, 0.0,  
                            0.0, 0.0, 0.0, 0.0 ]
        point4.time_from_start.sec = 12

        # Add the trajectory points to the trajectory
        goal_msg.trajectory.points = [point1, point2, point3, point4]

        # Send the goal to the action server
        self.get_logger().info('Sending goal...')
        self._send_goal_future = self._action_client.send_goal_async(goal_msg)
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        result = future.result()
        if result.accepted:
            self.get_logger().info('Goal accepted')
        else:
            self.get_logger().error('Goal rejected')

def main(args=None):
    rclpy.init(args=args)
    client = FollowJointTrajectoryClient()

    # Spin the node to process callbacks
    rclpy.spin(client)

    # Shutdown ROS 2 when finished
    rclpy.shutdown()

if __name__ == '__main__':
    main()
